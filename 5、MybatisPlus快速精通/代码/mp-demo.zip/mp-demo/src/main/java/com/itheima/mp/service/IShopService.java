package com.itheima.mp.service;

import com.itheima.mp.domain.po.Shop;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 
 * @since 2023-12-26
 */
public interface IShopService extends IService<Shop> {

}
