package com.itheima.mp.mapper;

import com.itheima.mp.domain.po.Shop;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2023-12-26
 */
public interface ShopMapper extends BaseMapper<Shop> {

}
